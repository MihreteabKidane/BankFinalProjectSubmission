package edu.mum.cs.cs425.studentproject.service;

public interface CredentialService {

}
